/* Supabase connection. Replace URL and KEY with your own project values. */
var CFG={url:'URL',key:'KEY'};
